from setuptools import setup, find_namespace_packages
# find_namespace_packages
setup(
    name="folder cleaner",
    version="2",
    description="can be used for the files arrangement in any folder",
    url="https://github.com/alimak86",
    author="Alisa Makusheva",
    author_email="alisamakusheva15@gmail.com",
    license="GPL",
    packages=find_namespace_packages(),
    install_requires=["pathlib", "Path",
                      "datetime", "os", "re", "shutil", "sys"]
)
